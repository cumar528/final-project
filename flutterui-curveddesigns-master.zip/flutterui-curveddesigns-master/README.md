# Curved Design

Code for a simple ui screen created with flutter.

Design credit - https://dribbble.com/shots/6687016-Foody-Food-by-Subscription

How do I code this - https://youtu.be/K1uH_SN4X0w

## Screenshots

![Screenshot_20190801-030839](https://user-images.githubusercontent.com/8137504/62318844-51c08900-b4ba-11e9-9aca-85b9641234ee.png)
![Screenshot_20190801-030856](https://user-images.githubusercontent.com/8137504/62318845-51c08900-b4ba-11e9-9390-aa9c35e0ce70.png)
![Screenshot_20190801-030910](https://user-images.githubusercontent.com/8137504/62318847-52591f80-b4ba-11e9-984d-0f6f400a92f7.png)
![Screenshot_20190801-030918](https://user-images.githubusercontent.com/8137504/62318848-52591f80-b4ba-11e9-8124-cddda049b70a.png)
